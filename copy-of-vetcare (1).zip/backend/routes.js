
// This file is deprecated. Please use the routes in backend/routes/ directory.
// This adapter ensures no "require is not defined" error occurs if accidentally loaded.

import express from 'express';
const router = express.Router();

export default router;
